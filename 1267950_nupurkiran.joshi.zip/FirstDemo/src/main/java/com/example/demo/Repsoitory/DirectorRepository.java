package com.example.demo.Repsoitory;


	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.demo.Entity.Director;


	@Repository("directorRepository")
	public interface DirectorRepository  extends JpaRepository<Director,Integer>{

		//Optional <Director>
		  public Director findByFirstName(String name);
		  
	}


