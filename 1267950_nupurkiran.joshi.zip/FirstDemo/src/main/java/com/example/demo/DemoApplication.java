package com.example.demo;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.AbstractApplicationContext;

import com.example.demo.DTO.DirectorDTO;
import com.example.demo.DTO.MovieDTO;
import com.example.demo.Service.MovieService;

@SpringBootApplication
public class DemoApplication {


	public static void main(String[] args) {
		AbstractApplicationContext context = (AbstractApplicationContext)SpringApplication.run(DemoApplication.class, args);
	    
		
		MovieService service = (MovieService)context.getBean("movieservice");
		//Insert 
		MovieDTO dto = new MovieDTO("BNC",LocalDate.now(),LocalDateTime.now());
		List<DirectorDTO> directorList = Arrays.asList(
				new DirectorDTO("abn", "vbn", "indore","nupur@infosys.com",7898917594L),
				new DirectorDTO("xyz","vdg","ujjain","alina@infy.com",7890753780L)
				);
	
		
		//Uncomment below code to add New Entries in Movie
		service.add(dto,directorList);  //this automates mapping of DIRECTORS IN MOVIE
		
		
        service.searchBasedOnTitle("ABC");
        
        
//        service.updateReleaseDate(LocalDate.of(2024, 6, 1), "ABC");
        
        
        /**
         * Get all Directors from Movie Title
         */
        System.out.println("================= Get all Directors from Movie Title ===================");
        
        service.getDirectorListFromTitle("ABC");
        
        /**
         * Get all Movies from Director Name
         */
        System.out.println(" ===================Get all Movies from Director Name=============");
        service.getMovieListFromDirectorName("xyz");
        
        
        //Get All movies
        //Display Log At Info Level
        System.out.println(service.displayAll().toString());       
	}

}

